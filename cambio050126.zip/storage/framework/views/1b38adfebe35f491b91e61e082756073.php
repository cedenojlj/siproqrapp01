<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Historical Movements Report')); ?></div>

                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-3">
                            <label for="productFilter" class="form-label">Product:</label>
                            <select wire:model.live="productId" id="productFilter" class="form-select">
                                <option value="">All Products</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="warehouseFilter" class="form-label">Warehouse:</label>
                            <select wire:model.live="warehouseId" id="warehouseFilter" class="form-select">
                                <option value="">All Warehouses</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="typeFilter" class="form-label">Movement Type:</label>
                            <select wire:model.live="movementType" id="typeFilter" class="form-select">
                                <option value="">All Types</option>
                                <option value="Entrada">Entrada</option>
                                <option value="Salida">Salida</option>
                                <option value="Devolucion">Devolucion</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="startDateFilter" class="form-label">Start Date:</label>
                            <input type="date" wire:model.live="startDate" id="startDateFilter" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label for="endDateFilter" class="form-label">End Date:</label>
                            <input type="date" wire:model.live="endDate" id="endDateFilter" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label for="sizeFilter" class="form-label">Size:</label>
                            <input type="text" wire:model.live="size" id="sizeFilter" class="form-control" placeholder="Enter size">
                        </div>
                    </div>

                    <div class="mb-3">
                        <button wire:click="generatePdf" class="btn btn-secondary">Generate PDF Report</button>
                    </div>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Product</th>
                                <th>Size</th>
                                <th>Warehouse</th>
                                <th>Quantity</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($movement->created_at->format('Y-m-d H:i:s')); ?></td>
                                    <td><?php echo e($movement->product->name); ?></td>
                                    <td><?php echo e($movement->product->size); ?></td>
                                    <td><?php echo e($movement->warehouse->name); ?></td>
                                    <td><?php echo e($movement->quantity); ?></td>
                                    <td><?php echo e(ucfirst($movement->type)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">No movements found matching the criteria.</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/report/historical-movements.blade.php ENDPATH**/ ?>