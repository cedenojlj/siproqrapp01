<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Petition Details')); ?> #<?php echo e($petition->id); ?></div>

                <div class="card-body">

                    <div class="mb-3">
                        <strong>Fecha:</strong> <?php echo e($petition->created_at->format('d/m/Y H:i:s')); ?>

                    </div>
                    <div class="mb-3">
                        <strong>User:</strong> <?php echo e($petition->user->name); ?>

                    </div>
                    <div class="mb-3">
                        <strong>Total Amount:</strong> <?php echo e(number_format($petition->total, 2)); ?>

                    </div>
                    <div class="mb-3">
                        <strong>Status:</strong> <?php echo e($petition->status); ?>

                    </div>

                    <hr>

                    <h5>Products in Petition</h5>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Size</th>
                                <th>Quantity</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $petition->petitionClassifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->classification->name); ?></td>
                                    <td><?php echo e($item->classification->size); ?></td>
                                    <td><?php echo e(number_format($item->quantity, 2)); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2" class="text-end"><strong>Total:</strong></td>
                                <td><?php echo e(number_format($petition->petitionClassifications->sum('quantity'), 2)); ?></td>
                            </tr>
                        </tfoot>
                    </table>

                    <div class="text-end">
                        <button wire:click="generatePdf" class="btn btn-primary">Generate PDF</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/petition/show.blade.php ENDPATH**/ ?>