
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Prices')); ?></div>

                <div class="card-body">
                    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="row mb-3">
                        <div class="col-md-6">,
                            <input wire:model.live="search" type="text" class="form-control"
                                placeholder="Search by product, sku, size, type or customer...">
                        </div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create precios')): ?>
                            <div class="col-md-6 text-end">
                                <a href="<?php echo e(route('prices.create')); ?>" class="btn btn-secondary"><i
                                        class="bi bi-plus"></i>Create</a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped table-responsive">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Product</th>
                                    <th>Sku</th>
                                    <th>Customer</th>
                                    <th>Price Quantity</th>
                                    <th>Price Weight</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($price->id); ?></td>
                                        <td><?php echo e($price->product->name); ?> - <?php echo e($price->product->type); ?> - <?php echo e($price->product->size); ?></td>
                                        <td><?php echo e($price->product->sku); ?></td>
                                        <td><?php echo e($price->customer->name); ?></td>
                                        <td><?php echo e($price->price_quantity); ?></td>
                                        <td><?php echo e($price->price_weight); ?></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update precios')): ?>
                                                <a href="<?php echo e(route('prices.edit', $price->id)); ?>" class="btn"><i
                                                        class="bi bi-pencil-square"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete precios')): ?>
                                                <button wire:click="delete(<?php echo e($price->id); ?>)" class="btn"><i
                                                        class="bi bi-trash"></i></button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($prices->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/price/index.blade.php ENDPATH**/ ?>