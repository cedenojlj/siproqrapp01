<!DOCTYPE html>
<html>
<head>
    <title>Historical Movements Report</title>
    <style>
        body {
            font-family: sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <img src="<?php echo e(public_path('img/logoMejorado.jpg')); ?>" alt="" srcset="" width="200px">
    <h1>Historical Movements Report</h1>

    <p><strong>Filters:</strong></p>
    <ul>
        <li>Product: <?php echo e($filters['product']); ?></li>
        <li>Warehouse: <?php echo e($filters['warehouse']); ?></li>
        <li>Type: <?php echo e($filters['type']); ?></li>
        <li>Start Date: <?php echo e($filters['startDate'] ?? 'N/A'); ?></li>
        <li>End Date: <?php echo e($filters['endDate'] ?? 'N/A'); ?></li>
    </ul>

    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Product</th>
                <th>Size</th>
                <th>Warehouse</th>
                <th>Quantity</th>
                <th>Type</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($movement->created_at->format('Y-m-d H:i:s')); ?></td>
                    <td><?php echo e($movement->product->name); ?></td>
                    <td><?php echo e($movement->product->size); ?></td>
                    <td><?php echo e($movement->warehouse->name); ?></td>
                    <td><?php echo e($movement->quantity); ?></td>
                    <td><?php echo e(ucfirst($movement->type)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No movements found matching the criteria.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/pdf/historical-movements.blade.php ENDPATH**/ ?>