<!DOCTYPE html>
<html>
<head>
    <title>Order Details</title>
    <style>
        body {
            font-family: sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .total {
            text-align: right;
            margin-top: 20px;
            font-size: 1.2em;
            font-weight: bold;
        }
        .text-end {
            text-align: right;
        }
    </style>
</head>
<body>

    <div class="text-end">
        <img src="<?php echo e(public_path('img/logoMejorado.jpg')); ?>" alt="" srcset="" width="200px"> 
    </div>
      
  
    <h2>Order #<?php echo e($order->id); ?></h2>

    <p><strong>Date:</strong> <?php echo e($order->created_at->format('d/m/Y H:i:s')); ?></p>
    <p><strong>Customer:</strong> <?php echo e($order->customer->name); ?></p>
    <p><strong>Warehouse:</strong> <?php echo e($order->warehouse->name); ?></p>
    <p><strong>Order Type:</strong> <?php echo e(ucfirst($order->order_type)); ?></p>
    <p><strong>Status:</strong> <?php echo e($order->status); ?></p>

    <h2>Products</h2>
    <table>
        <thead>
            <tr>
                <th>SKU</th>
                <th>Product</th>
                <th>Size</th>
                <th>Quantity</th>
                <th>NW</th>
                <th>Price</th>
                <th>Price2</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $totalWeight = 0;
            ?>
            <?php $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $totalWeight += $item->product->GN * $item->quantity;
                ?>
                <tr>
                    <td><?php echo e($item->product->sku); ?></td>
                    <td><?php echo e($item->product->name); ?></td>
                    <td><?php echo e($item->product->size); ?></td>
                    <td><?php echo e(number_format($item->quantity, 2)); ?></td>
                    <td><?php echo e($item->product->GN); ?></td>                    
                    <td><?php echo e(number_format($item->price, 2)); ?></td>
                    <?php if($item->product->classification->unit_type == 'Peso'): ?>
                        <td><?php echo e(number_format($item->price / $item->product->GN, 2)); ?></td>
                    <?php else: ?>
                        <td><?php echo e(number_format($item->price, 2)); ?></td>
                    <?php endif; ?>
                    
                    <td><?php echo e(number_format($item->quantity * $item->price, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="7" class="text-end"><strong>Total:</strong></td>
                <td>$<?php echo e(number_format($order->total, 2)); ?></td>
            </tr>

            <tr>
                <td colspan="7" class="text-end"><strong>Total Weight:</strong></td>
                <td><?php echo e(number_format($totalWeight, 2)); ?></td>
            </tr>
        </tfoot>
    </table>


   
</body>
</html>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/pdf/order-details.blade.php ENDPATH**/ ?>