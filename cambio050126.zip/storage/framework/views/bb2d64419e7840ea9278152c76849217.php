<div>
    <div class="row mb-3">
        <div class="col-md-2">
            <label for="customerName">Customer Name</label>
            <input type="text" class="form-control" wire:model.live="customerName" id="customerName">
        </div>
        <div class="col-md-2">
            <label for="size">Size</label>
            <input type="text" class="form-control" wire:model.live="size" id="size">
        </div>
        <div class="col-md-2">
            <label for="productId">Product</label>
            <select wire:model.live="productId" id="productId" class="form-control">
                <option value="">All</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
        <div class="col-md-2">
            <label for="warehouseId">Warehouse</label>
            <select wire:model.live="warehouseId" id="warehouseId" class="form-control">
                <option value="">All</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
        <div class="col-md-2">
            <label for="movementType">Movement Type</label>
            <select wire:model.live="movementType" id="movementType" class="form-control">
                <option value="">All</option>
                <option value="Entrada">Entrada</option>
                <option value="Devolucion">Devolucion</option>               
                <option value="Salida">Salida</option>
            </select>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-2">
            <label for="startDate">Start Date</label>
            <input type="date" class="form-control" wire:model.live="startDate" id="startDate">
        </div>
        <div class="col-md-2">
            <label for="endDate">End Date</label>
            <input type="date" class="form-control" wire:model.live="endDate" id="endDate">
        </div>

        
        <div class="col-md-2">
            <label for="sku">Sku</label>
            <input type="text" class="form-control" wire:model.live="sku" id="sku">
        </div>

        <div class="col-md-2 align-self-end">
            <button class="btn btn-primary" wire:click="generatePdf">Export to PDF</button>
        </div>
    </div>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Date</th>
                <th>Product</th>
                <th>SKU</th>
                <th>Warehouse</th>
                <th>Type</th>
                <th>Quantity</th>
                <th>Customer Name</th>
                <th>Size</th>
                <th>NW</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>

            <?php
                $totalcuenta = 0;
            ?>

            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                <?php                

                    if ($movement->type === 'Entrada') {
                        $subtotalItem= (-1) * $movement->subtotal;
                    }else {
                        $subtotalItem = $movement->subtotal;                    }

                    $totalcuenta += $subtotalItem;

                ?>
                <tr>
                    <td><?php echo e($movement->created_at->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($movement->product_name); ?></td>
                    <td><?php echo e($movement->product_sku); ?></td>
                    <td><?php echo e($movement->warehouse_name); ?></td>
                    <td><?php echo e(ucfirst($movement->type)); ?></td>
                    <td><?php echo e($movement->quantity); ?></td>
                    <td><?php echo e($movement->customer_name); ?></td>
                    <td><?php echo e($movement->product_size); ?></td>
                    <td><?php echo e($movement->product_gn); ?></td>
                    <td><?php echo e(number_format($subtotalItem, 2)); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">No movements found.</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
        <tfoot>
            <tr>
                <td colspan="8" class="text-right"><strong>Total:</strong></td>
                <td><strong><?php echo e(number_format($totalcuenta, 2)); ?></strong></td>
            </tr>
        </tfoot>
    </table>
</div><?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/report/detailed-report.blade.php ENDPATH**/ ?>