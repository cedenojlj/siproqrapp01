<div>
    <div class="container py-4">
        <div class="card">
            <div class="card-header">
                <h3>Actualizar Precios de Productos por Clasificación</h3>
            </div>
            <div class="card-body">
                <form wire:submit.prevent="updatePrices">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <label for="classification" class="form-label">Clasificación</label>
                            <select wire:model.lazy="selectedClassification" id="classification" class="form-select">
                                <option value="">Seleccione una clasificación</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $classifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($classification->id); ?>"><?php echo e($classification->code); ?> - <?php echo e($classification->description); ?> - <?php echo e($classification->size); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedClassification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-md-4">
                            <label for="precio_unidad" class="form-label">Nuevo Precio por Unidad</label>
                            <input wire:model.lazy="precio_unidad" type="number" step="0.01" class="form-control" id="precio_unidad" placeholder="Ej: 12.50">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['precio_unidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-md-4">
                            <label for="precio_peso" class="form-label">Nuevo Precio por Peso</label>
                            <input wire:model.lazy="precio_peso" type="number" step="0.01" class="form-control" id="precio_peso" placeholder="Ej: 25.75">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['precio_peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>

                    <hr>

                    <h5 class="mt-4">Seleccionar Clientes</h5>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedCustomers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert alert-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead class="thead-dark">
                                <tr>
                                    <th>
                                        <!-- Podrías agregar aquí una funcionalidad para seleccionar/deseleccionar todos -->
                                    </th>
                                    <th>Nombre</th>
                                    <th>Email</th>
                                    <th>Teléfono</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="<?php echo e($customer->id); ?>" wire:model.lazy="selectedCustomers" id="customer-<?php echo e($customer->id); ?>">
                                            </div>
                                        </td>
                                        <td><?php echo e($customer->name); ?></td>
                                        <td><?php echo e($customer->email); ?></td>
                                        <td><?php echo e($customer->phone); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No se encontraron clientes activos.</td>
                                    </tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-end mt-4">
                        <button type="submit" class="btn btn-primary">
                            <span wire:loading.remove wire:target="updatePrices">Actualizar Precios</span>
                            <span wire:loading wire:target="updatePrices">Actualizando...</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/price/update-by-classification.blade.php ENDPATH**/ ?>