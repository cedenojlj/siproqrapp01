<div>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-md-3">
                    <input wire:model.live="filterSku" type="text" class="form-control" placeholder="Buscar por SKU...">
                </div>
                <div class="col-md-3">
                    <input wire:model.live="filterInvoiceNumber" type="text" class="form-control" placeholder="Buscar por N° Factura...">
                </div>
                <div class="col-md-3">
                    <input wire:model.live="filterDate" type="date" class="form-control">
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Producto</th>
                        <th>Type</th>
                        <th>Size</th>
                        <th>NW</th>
                        <th>N° Factura</th>
                        <th>Fecha Creación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($product->sku); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->type); ?></td>
                            <td><?php echo e($product->size); ?></td>
                            <td><?php echo e($product->GN); ?></td>
                            <td><?php echo e($product->invoice_number); ?></td>
                            <td><?php echo e($product->created_at->format('d/m/Y H:i:s')); ?></td>
                            <td>
                                <button wire:click="downloadQrPdf(<?php echo e($product->id); ?>)" class="btn btn-danger btn-sm">PDF</button>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">No se encontraron productos.</td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php echo e($products->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/product/filterable-table.blade.php ENDPATH**/ ?>