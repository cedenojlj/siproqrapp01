<div>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form wire:submit.prevent="applyPayment">
        <div class="card">
            <div class="card-header">
                <h4>Registrar Abono de Cliente</h4>
            </div>
            <div class="card-body">
                <!-- Selector de Cliente (se puede mejorar con un buscador) -->
                <div class="form-group">
                    <label for="customer">Cliente</label>
                    <select id="customer" wire:model.live="customer_id" class="form-control">
                        <option value="">-- Seleccione un cliente --</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!--[if BLOCK]><![endif]--><?php if($selectedCustomer): ?>
                    <div class="mt-3">
                        <p><strong>Saldo a favor actual:</strong> <span class="badge text-bg-success">$<?php echo e(number_format($selectedCustomer->credit_balance, 2)); ?></span></p>

                        <p><strong>Deuda total actual:</strong> <span class="badge text-bg-warning">$<?php echo e(number_format($selectedCustomer->orders->sum('deuda'), 2)); ?></span></p>

                        <hr>
                        <h5>Órdenes Pendientes:</h5>
                        <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->orders->isNotEmpty()): ?>
                            <ul class="list-group">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedCustomer->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        Orden #<?php echo e($order->id); ?> (<?php echo e($order->created_at->format('d/m/Y H:i:s')); ?>) <span class="badge text-bg-warning">Deuda: $<?php echo e(number_format($order->deuda, 2)); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        <?php else: ?>
                            <p>Este cliente no tiene órdenes pendientes.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <hr>

                <!-- Campos del Abono -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="monto_abono">Monto del Abono</label>
                            <input type="number" step="0.01" id="monto_abono" wire:model="monto_abono" class="form-control">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['monto_abono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="fecha_pago">Fecha del Pago</label>
                            <input type="date" id="fecha_pago" wire:model="fecha_pago" class="form-control">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fecha_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="metodo_pago">Metodo de Pago</label>
                            <select id="metodo_pago" wire:model="metodo_pago" class="form-control">
                                <option value="">-- Seleccione un Metodo --</option>
                                <option value="Efectivo">Efectivo</option>
                                <option value="Transferencia">Transferencia</option>
                                <option value="Pago_Movil">Pago Movil</option>
                                <option value="Zelle">Zelle</option>
                                <option value="Divisa">USDT</option>
                                <option value="Euro">Banesco Panama</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['metodo_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
                <div class="form-group mt-3">
                    <label for="notas">Notas (Opcional)</label>
                    <textarea id="notas" wire:model="notas" class="form-control"></textarea>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                    <span wire:loading.remove wire:target="applyPayment">Aplicar Pago</span>
                    <span wire:loading wire:target="applyPayment">Procesando...</span>
                </button>
            </div>
        </div>
    </form>
</div><?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/customer/payment-manager.blade.php ENDPATH**/ ?>