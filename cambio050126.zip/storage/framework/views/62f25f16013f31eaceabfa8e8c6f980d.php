<!DOCTYPE html>
<html>
<head>
    <title>Detailed Report</title>
    <style>
        body { font-family: sans-serif; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #f2f2f2; }
        .text-right { text-align: right; }
    </style>
</head>
<body>
    
    <img src="<?php echo e(public_path('img/logoMejorado.jpg')); ?>" alt="" srcset="" width="200px">  

    <h1>Detailed Report</h1>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Product</th>
                <th>Size</th>
                <th>Warehouse</th>
                <th>Type</th>
                <th>Quantity</th>
                <th>Customer Name</th>                
                <th>GN</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>

             <?php
                $totalcuenta = 0;
            ?>

            <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <?php                

                    if ($movement->type === 'Entrada') {
                        $subtotalItem= (-1) * $movement->subtotal;
                    }else {
                        $subtotalItem = $movement->subtotal;                    }

                    $totalcuenta += $subtotalItem;

                ?>

                <tr>
                    <td><?php echo e($movement->created_at->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($movement->product_name); ?></td>
                    <td><?php echo e($movement->product_size); ?></td>
                    <td><?php echo e($movement->warehouse_name); ?></td>
                    <td><?php echo e(ucfirst($movement->type)); ?></td>
                    <td><?php echo e($movement->quantity); ?></td>
                    <td><?php echo e($movement->customer_name); ?></td>                    
                    <td><?php echo e($movement->product_gn); ?></td>
                     <td><?php echo e(number_format($subtotalItem, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">No movements found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="8" class="text-right"><strong>Total:</strong></td>
                <td><strong><?php echo e(number_format($totalcuenta, 2)); ?></strong></td>
            </tr>
        </tfoot>
    </table>
</body>
</html>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/pdf/detailed-report.blade.php ENDPATH**/ ?>