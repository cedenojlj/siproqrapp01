<div>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Actualizar Almacén desde QR</h3>
        </div>
        <div class="card-body">

            <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <div class="row">
                <div class="col-md-6 mx-auto mb-4" wire:ignore>
                    <div id="qr-reader" style="width:100%;"></div>
                </div>
            </div>

            <!--[if BLOCK]><![endif]--><?php if($productFound): ?>
                <form wire:submit.prevent="updateWarehouse">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nombre</label>
                                <input type="text" class="form-control" value="<?php echo e($productData['name'] ?? ''); ?>"
                                    readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>SKU</label>
                                <input type="text" class="form-control" value="<?php echo e($productData['sku'] ?? ''); ?>"
                                    readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tipo</label>
                                <input type="text" class="form-control" value="<?php echo e($productData['type'] ?? ''); ?>"
                                    readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tamaño</label>
                                <input type="text" class="form-control" value="<?php echo e($productData['size'] ?? ''); ?>"
                                    readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Peso Neto (NW)</label>
                                <input type="text" class="form-control" value="<?php echo e($productData['NW'] ?? ''); ?>"
                                    readonly>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="warehouse">Asignar Almacén</label>
                                <select wire:model="selectedWarehouseId" id="warehouse"
                                    class="form-control <?php $__errorArgs = ['selectedWarehouseId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">-- Seleccione un Almacén --</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedWarehouseId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>

                    <div class="d-grid gap-2 mt-3">
                        <button type="submit" class="btn btn-primary">Actualizar Almacén</button>                        
                    </div>
                </form>
            <?php else: ?>
                <div class="text-center">
                    <p class="text-muted">Esperando escaneo de código QR...</p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
           
        </div>

        <!--[if BLOCK]><![endif]--><?php if($escaneoInicial): ?>
            <div class="d-grid gap-2 mb-3">
                <button id="llamado" class="btn btn-success" wire:click="$dispatch('abrirScanner')">Scannear</button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!--[if BLOCK]><![endif]--><?php if($escaneoInicial): ?>
            <div class="d-grid gap-2">
                <button id="llamadoCerrar" class="btn btn-secondary" wire:click="$dispatch('cerrarScanner')">Close
                    Scanner</button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>    

        <?php
        $__scriptKey = '534696773-0';
        ob_start();
    ?>
        <script>

            let html5QrcodeScanner=null;

            function onScanSuccess(decodedText, decodedResult) {

                // Manejar el éxito del escaneo.
                console.log(`Scan result: ${decodedText}`, decodedResult);
                // Enviar el resultado al backend de Livewire
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('processQrCode', decodedText);
                // Opcional: detener el escáner después de una detección exitosa
                html5QrcodeScanner.clear();
            }

            $wire.on('abrirScanner', () => {
                // Código a ejecutar cuando se muestra el modal
               // alert('¡El escáner ha sido mostrado exitosamente!');
                //$wire.dispatch('cerrarModal');

               html5QrcodeScanner = new Html5QrcodeScanner(
                    "qr-reader", {
                        fps: 10,
                        qrbox: 250
                    });
                html5QrcodeScanner.render(onScanSuccess);
            });


            $wire.on('cerrarScanner', () => {
                // Código a ejecutar cuando se cierra el modal
                //alert('¡El escáner ha sido cerrado exitosamente!');
                html5QrcodeScanner.clear();
            });
        </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/product/update-warehouse-from-qr.blade.php ENDPATH**/ ?>