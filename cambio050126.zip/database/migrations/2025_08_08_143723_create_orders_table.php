<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained('customers')->onUpdate('cascade')->onDelete('cascade');
            $table->foreignId('user_id')->constrained('users')->onUpdate('cascade')->onDelete('cascade');
            $table->foreignId('warehouse_id')->constrained('warehouses')->onUpdate('cascade')->onDelete('cascade');
            $table->enum('order_type', ['Entrada','Devolucion','Salida','Interna'])->default('Salida');
            $table->decimal('total');
            $table->enum('status', ['Pendiente', 'Aprobada', 'Rechazada']);
            $table->enum('payment_status', ['pagado', 'parcial','pendiente'])->default('pendiente');
            $table->decimal('monto_pagado')->default(0);
            $table->date('date_expiration')->default(now());
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
