<div>
    <div class="container py-4">
        <div class="card">
            <div class="card-header">
                <h3>Actualizar Precios por Cliente y Clasificación</h3>
            </div>
            <div class="card-body">
                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <div class="row mb-4">
                    <div class="col-md-12">
                        <input wire:model.live.debounce.300ms="search" type="text" class="form-control" placeholder="Buscar por cliente, código, size, o descripción de la clasificación...">
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>Cliente</th>
                                <th>Código</th>
                                <th>Descripción</th>
                                <th>Size</th>
                                <th style="width: 150px;">Precio_Unit.</th>
                                <th style="width: 150px;">Precio_Peso</th>
                                <th style="width: 100px;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr wire:key="<?php echo e($item->customer_id); ?>-<?php echo e($item->classification_id); ?>">
                                    <td><?php echo e($item->customer_name); ?></td>
                                    <td><?php echo e($item->classification_code); ?></td>
                                    <td><?php echo e($item->classification_description); ?></td>
                                    <td><?php echo e($item->classification_size); ?></td>
                                    <td>
                                        <input type="number" step="0.01" class="form-control"
                                               wire:model="inputs.<?php echo e($item->customer_id); ?>.<?php echo e($item->classification_id); ?>.price_quantity">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['inputs.' . $item->customer_id . '.' . $item->classification_id . '.price_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <input type="number" step="0.01" class="form-control"
                                               wire:model="inputs.<?php echo e($item->customer_id); ?>.<?php echo e($item->classification_id); ?>.price_weight">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['inputs.' . $item->customer_id . '.' . $item->classification_id . '.price_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td class="text-center">
                                        <button wire:click="save(<?php echo e($item->customer_id); ?>, <?php echo e($item->classification_id); ?>)" class="btn btn-sm btn-primary">
                                            <span wire:loading.remove wire:target="save(<?php echo e($item->customer_id); ?>, <?php echo e($item->classification_id); ?>)">Actualizar</span>
                                            <span wire:loading wire:target="save(<?php echo e($item->customer_id); ?>, <?php echo e($item->classification_id); ?>)">...</span>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No se encontraron registros.</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    <?php echo e($data->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/price/customer-price-update.blade.php ENDPATH**/ ?>