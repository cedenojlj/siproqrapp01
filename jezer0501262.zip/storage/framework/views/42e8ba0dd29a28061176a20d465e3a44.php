<div>

   
    <div class="input-group mb-3">
        
        <input type="text" wire:model.live="search" class="form-control mb-3" placeholder="buscar por nombre o tamaño">
    </div>

    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $codigos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($codigo->code); ?></h5>
                <h6 class="card-subtitle mb-2 text-body-secondary"><?php echo e($codigo->size); ?></h6>
                <p class="card-text"><?php echo e($codigo->description); ?></p>
                <button type="button" wire:click="agregarCodigo(<?php echo e($codigo->id); ?>)" class="btn btn-secondary">Add</button>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <p>No se encontraron resultados.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->





</div>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/product/lista.blade.php ENDPATH**/ ?>