
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-bs-theme="light">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>

<body class="antialiased">

    <div class="wrapper">
        <!-- Sidebar -->
        <aside id="sidebar">
            <div class="d-flex">
                
                <div class="sidebar-logo">
                    <a href="<?php echo e(route('dashboard.index')); ?>"><i class="bi bi-grid"></i><span
                            class="ps-2">SiproqApp</span></a>
                </div>
            </div>
            <ul class="sidebar-nav">
                <li class="sidebar-item active">
                    <a href="<?php echo e(route('dashboard.index')); ?>" class="sidebar-link">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read products')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('products.index')); ?>" class="sidebar-link">
                            <i class="bi bi-box-seam"></i>
                            <span>Productos</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read customers')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('customers.index')); ?>" class="sidebar-link">
                            <i class="bi bi-people"></i>
                            <span>Clientes</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read warehouses')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('warehouses.index')); ?>" class="sidebar-link">
                            <i class="bi bi-houses"></i>
                            <span>Almacenes</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read petitions')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('petitions.index')); ?>" class="sidebar-link">
                            <i class="bi bi-receipt"></i>
                            <span>Pedidos</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read orders')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('orders.index')); ?>" class="sidebar-link">
                            <i class="bi bi-inboxes"></i>
                            <span>Ordenes</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read prices')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('prices.index')); ?>" class="sidebar-link">
                            <i class="bi bi-receipt"></i>
                            <span>Precios</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read users')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('users.index')); ?>" class="sidebar-link">
                            <i class="bi bi-person-lock"></i>
                            <span>Roles</span>
                        </a>
                    </li>
                <?php endif; ?>



                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver reportes')): ?>
                    <li class="sidebar-item">
                        <a href="#reports-submenu" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            <span>Reportes</span>
                            <i class="bi bi-chevron-down ms-auto"></i>
                        </a>
                        <ul id="reports-submenu" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.inventory-by-warehouse')); ?>" class="sidebar-link">Inv. por
                                    Almacén</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.historical-movements')); ?>" class="sidebar-link">Mov.
                                    Históricos</a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                

                <?php if(auth()->guard()->check()): ?>
                    <li class="sidebar-item">
                        <a href="#login-submenu" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            <span><?php echo e(Auth::user()->name); ?></span>
                            <i class="bi bi-chevron-down ms-auto"></i>
                        </a>
                        <ul id="login-submenu" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>

                        </ul>
                    </li>

                <?php endif; ?>


                
            </ul>
            <div class="sidebar-footer">
                <a href="#" id="theme-toggle" class="sidebar-link">
                    <i class="bi bi-sun"></i>
                    <span>Modo Claro</span>
                </a>
            </div>
        </aside>

        <!-- Page Content -->
        <div class="main">
            <nav class="navbar navbar-expand px-3 border-bottom">
                <button class="btn" id="sidebar-toggle" type="button">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Navbar elements here -->
            </nav>
            <main class="content px-4 py-3">
                <div class="container-fluid">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.index', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2695298489-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>

</html>







<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/home.blade.php ENDPATH**/ ?>