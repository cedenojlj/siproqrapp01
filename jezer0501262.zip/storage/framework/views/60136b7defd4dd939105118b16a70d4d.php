<div class="row justify-content-start">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header"><?php echo e(__('Historial de Abonos')); ?></div>

            <div class="card-body">

                <div class="row mb-3">
                    <div class="col-md-3 mb-sm-2">
                        <label for="search_order"># Orden</label>
                        <input wire:model.live="search_order" type="text" class="form-control"
                            placeholder="Buscar por # de orden...">
                    </div>
                    <div class="col-md-3 mb-sm-2">
                        <label for="customer_id">Cliente</label>
                        <select wire:model.live="customer_id" class="form-select">
                            <option value="">Todos los Clientes</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <div class="col-md-3 mb-sm-2">
                       <label for="fechaInicio">Fecha Inicio</label>
                        <input wire:model.live="fechaInicio" type="date" class="form-control">
                    </div>
                    <div class="col-md-3 mb-sm-2">
                       <label for="fechaFin">Fecha Fin</label>
                        <input wire:model.live="fechaFin" type="date" class="form-control">
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <button wire:click="exportPdf" class="btn btn-danger"><i class="bi bi-file-pdf"></i> Exportar a PDF</button>
                    </div>
                    <div class="col-md-6 text-end">
                        <h4>Total Abonado: <span class="badge bg-success">$<?php echo e(number_format($totalAbonado, 2)); ?></span></h4>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Fecha Abono</th>
                                <th># Orden</th>
                                <th>Cliente</th>
                                <th>Monto Abonado</th>
                                <th>Método de Pago</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $paymentApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($application->payment->fecha_pago); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('orders.show', $application->order_id)); ?>"><?php echo e($application->order_id); ?></a>
                                    </td>
                                    <td><?php echo e($application->payment->customer->name); ?></td>
                                    <td>$<?php echo e(number_format($application->monto_aplicado, 2)); ?></td>
                                    <td><?php echo e($application->payment->metodo_pago); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center">No hay registros para mostrar.</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>

                <?php echo e($paymentApplications->links()); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/report/payment-history.blade.php ENDPATH**/ ?>