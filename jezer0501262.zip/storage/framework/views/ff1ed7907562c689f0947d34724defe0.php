<div class="row justify-content-start">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header"><?php echo e(__('Debt Report')); ?></div>

            <div class="card-body">
                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <div class="row mb-3">
                    <div class="col-md-3 mb-sm-2">
                        <label for="search">Search</label>
                        <input wire:model.live="search" type="text" class="form-control"
                            placeholder="Search orders...">
                    </div>
                    <div class="col-md-3 mb-sm-2">
                        <label for="customerId">Customer</label>
                        <select wire:model.live="customerId" class="form-control">
                            <option value="">All Customers</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <div class="col-md-3 mb-sm-2">
                        <label for="startDate">Start Date</label>
                        <input wire:model.live="startDate" type="date" class="form-control">
                    </div>
                    <div class="col-md-3 mb-sm-2">
                        <label for="endDate">End Date</label>
                        <input wire:model.live="endDate" type="date" class="form-control">
                    </div>
                    
                    
                    <div class="col-md-3 mb-sm-2">
                        <label for="paymentStatus">Payment Status</label>
                        <select wire:model.live="paymentStatus" class="form-control">
                            <option value="">All Statuses</option>
                            <option value="pendiente">Pendiente</option>
                            <option value="parcial">Parcial</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-sm-2 align-self-end">
                        <button wire:click="generatePdf" class="btn btn-primary">Generate PDF</button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Fecha</th>
                                <th>Customer</th>
                                <th>Warehouse</th>
                                <th>Type</th>
                                <th>Total Amount</th>
                                <th>Payment Status</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->created_at->format('d/m/Y H:i:s')); ?></td>
                                    <td><?php echo e($order->customer->name); ?></td>
                                    <td><?php echo e($order->warehouse->name); ?></td>
                                    <td><?php echo e(ucfirst($order->order_type)); ?></td>
                                    <td>$<?php echo e(number_format($order->monto_pagado, 2)); ?> / $<?php echo e(number_format($order->total, 2)); ?></td>
                                    <td>
                                        <?php
                                            $badgeClass = '';
                                            switch ($order->payment_status) {
                                                case 'pagado':
                                                    $badgeClass = 'text-bg-success';
                                                    break;
                                                case 'parcial':
                                                    $badgeClass = 'text-bg-warning';
                                                    break;
                                                case 'pendiente':
                                                default:
                                                    $badgeClass = 'text-bg-danger';
                                                    break;
                                            }
                                        ?>
                                        <span class="badge <?php echo e($badgeClass); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $order->payment_status))); ?></span>
                                    </td>
                                    <td><?php echo e($order->status); ?></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read orders')): ?>
                                            <a href="<?php echo e(route('orders.show', $order->id)); ?>" class="btn"><i
                                                    class="bi bi-eye"></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update orders')): ?>
                                            <a href="<?php echo e(route('orders.edit', $order->id)); ?>" class="btn"><i
                                                    class="bi bi-pencil-square"></i></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
                <div class="total">
                    <p>Total Pending: $<?php echo e(number_format($totalPending, 2)); ?></p>
                </div>

                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/report/debt-report.blade.php ENDPATH**/ ?>