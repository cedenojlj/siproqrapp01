<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Inventory Report by Warehouse')); ?></div>

                <div class="card-body">
                    <div class="mb-3">
                        <label for="warehouseFilter" class="form-label">Filter by Warehouse:</label>
                        <select wire:model.live="selectedWarehouseId" id="warehouseFilter" class="form-select">
                            <option value="">All Warehouses</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>

                    <div class="mb-3">
                        <button wire:click="generatePdf" class="btn btn-secondary">Generate PDF Report</button>
                    </div>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Product</th>
                                <th>Size</th>                                
                                <th>Warehouse</th>
                                <th>Stock</th>
                                <th>Unit Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->product->type); ?></td>
                                    <td><?php echo e($item->product->name); ?></td>
                                    <td><?php echo e($item->product->size); ?></td>                                    
                                    <td><?php echo e($item->warehouse->name); ?></td>
                                    <td><?php echo e($item->stock); ?></td>
                                    <td><?php echo e($item->product->classification->unit_type); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3">No inventory data found.</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/report/inventory-by-warehouse.blade.php ENDPATH**/ ?>