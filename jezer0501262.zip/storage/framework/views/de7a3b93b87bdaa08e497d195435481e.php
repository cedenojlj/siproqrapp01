<!DOCTYPE html>
<html>
<head>
    <title>Detalle de Inventario por Clasificación</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h1>Detalle de Inventario por Clasificación</h1>

    <p>Fecha: <?php echo e(now()->format('d/m/Y H:i')); ?></p>

    <p>Almacén: <?php echo e($warehouse->name ?? 'Todos los almacenes'); ?></p>
    
    <table>
        <thead>
            <tr>
                <th>Código</th>
                <th>Descripción</th>
                <th>Tamaño</th>
                <th>SKU</th>
                <th>Stock</th>
                <th>Tipo Unidad</th>
                <th>NW</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->code); ?></td>
                    <td><?php echo e($item->description); ?></td>
                    <td><?php echo e($item->size); ?></td>
                    <td><?php echo e($item->sku); ?></td>
                    <td><?php echo e($item->stock); ?></td>
                    <td><?php echo e($item->unit_type); ?></td>
                    <td><?php echo e($item->GN); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">No hay datos disponibles</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot> 
            <tr>
                <td colspan="4" class="text-right"><strong>Total:</strong></td>
                <td><?php echo e($data->sum('stock')); ?></td>
                <td></td>
                <td><?php echo e($data->sum('GN')); ?></td>
            </tr>
        </tfoot>
    </table>
</body>
</html>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/pdf/inventory-by-classification-detail.blade.php ENDPATH**/ ?>