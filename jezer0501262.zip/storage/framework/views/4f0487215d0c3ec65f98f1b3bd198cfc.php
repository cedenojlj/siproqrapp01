<!DOCTYPE html>
<html>

<head>
    <title>Petition Details</title>
    <style>
        body {
            font-family: sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .total {
            text-align: right;
            margin-top: 20px;
            font-size: 1.2em;
            font-weight: bold;
        }
    </style>
</head>

<body>


    <h2>Report of Petition #<?php echo e($petition->id); ?></h2>
    <p><strong>Date:</strong> <?php echo e($petition->created_at->format('d/m/Y H:i:s')); ?></p>
    
    
    <p><strong>User:</strong> <?php echo e($petition->user->name); ?></p>
    <p><strong>Status:</strong> <?php echo e($petition->status); ?></p>

    <h3>Products</h3>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Size</th>
                <th>Quantity</th>
                
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $petition->petitionClassifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->classification->code); ?></td>
                    <td><?php echo e($item->classification->size); ?></td>
                    <td><?php echo e(number_format($item->quantity, 2)); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2" class="text-end"><strong>Total:</strong></td>
                <td><?php echo e(number_format($petition->petitionClassifications->sum('quantity'), 2)); ?></td>
            </tr>
        </tfoot>
    </table>

    
</body>

</html>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/pdf/petition-details.blade.php ENDPATH**/ ?>