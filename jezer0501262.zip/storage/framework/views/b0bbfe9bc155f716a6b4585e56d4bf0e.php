<div>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Inventario por Clasificación</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Almacén</label>
                        <select wire:model.live="warehouseId" class="form-control">
                            <option value="">Todos</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Código</label>
                        <input wire:model.live="code" type="text" class="form-control" placeholder="Filtrar por código">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label>Tamaño</label>
                        <input wire:model.live="size" type="text" class="form-control" placeholder="Filtrar por tamaño">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Descripción</label>
                        <input wire:model.live="description" type="text" class="form-control" placeholder="Filtrar por descripción">
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <button wire:click="exportPdf" class="btn btn-primary">Exportar a PDF</button>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Descripción</th>
                                <th>Tamaño</th>
                                
                                <th>Stock</th>
                                <th>Tipo Unidad</th>
                                <th>NW</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->code); ?></td>
                                    <td><?php echo e($item->description); ?></td>
                                    <td><?php echo e($item->size); ?></td>
                                    
                                    <td><?php echo e($item->total_stock); ?></td>
                                    <td><?php echo e($item->unit_type); ?></td>
                                    <td><?php echo e($item->total_gn); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No hay datos disponibles</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-right">Total:</th>
                                
                                <th><?php echo e($data->sum('total_stock')); ?></th>
                                <th></th>
                                <th><?php echo e($data->sum('total_gn')); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/report/inventory-by-classification.blade.php ENDPATH**/ ?>