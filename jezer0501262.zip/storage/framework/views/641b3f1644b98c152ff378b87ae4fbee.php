<!DOCTYPE html>
<html>

<head>
    <title>Inventario por Clasificación</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>

<body>
    <h1>Inventario por Clasificación</h1>

    <p>Fecha: <?php echo e(now()->format('d/m/Y H:i')); ?></p>

    <p>Almacén: <?php echo e($warehouse->name ?? 'Todos los almacenes'); ?></p>

    <table>
        <thead>
            <tr>
                <th>Código</th>
                <th>Descripción</th>
                <th>Tamaño</th>
                <th>SKU Count</th>
                <th>Stock</th>
                <th>Tipo Unidad</th>
                <th>NW</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->code); ?></td>
                    <td><?php echo e($item->description); ?></td>
                    <td><?php echo e($item->size); ?></td>
                    <td><?php echo e($item->sku_count); ?></td>
                    <td><?php echo e($item->total_stock); ?></td>
                    <td><?php echo e($item->unit_type); ?></td>
                    <td><?php echo e($item->total_gn); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">No hay datos disponibles</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3" class="text-right">Total:</th>
                <th><?php echo e($data->sum('sku_count')); ?></th>
                <th><?php echo e($data->sum('total_stock')); ?></th>
                <th></th>
                <th><?php echo e($data->sum('total_gn')); ?></th>
            </tr>
        </tfoot>
    </table>
</body>

</html>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/pdf/inventory-by-classification.blade.php ENDPATH**/ ?>