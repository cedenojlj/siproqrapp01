<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Abonos</title>
    <style>
        body {
            font-family: sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .total {
            font-weight: bold;
            font-size: 1.2em;
            text-align: right;
            padding-top: 10px;
        }
        .text-end {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="text-end">
        <img src="<?php echo e(public_path('img/logoMejorado.jpg')); ?>" alt="" srcset="" width="200px"> 
    </div>
    <h1>Historial de Abonos</h1>
    <table>
        <thead>
            <tr>
                <th>Fecha Abono</th>
                <th># Orden</th>
                <th>Cliente</th>
                <th>Monto Abonado</th>
                <th>Metodo de Pago</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $paymentApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($application->payment->fecha_pago); ?></td>
                    <td><?php echo e($application->order_id); ?></td>
                    <td><?php echo e($application->payment->customer->name); ?></td>
                    <td>$<?php echo e(number_format($application->monto_aplicado, 2)); ?></td>
                    <td><?php echo e($application->payment->metodo_pago); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" style="text-align: center;">No hay registros para mostrar.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="total">
        Total Abonado: $<?php echo e(number_format($totalAbonado, 2)); ?>

    </div>
</body>
</html>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/pdf/payment-history.blade.php ENDPATH**/ ?>