<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-bs-theme="light">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
</head>

<body class="antialiased">

    <div class="wrapper">
        <!-- Sidebar -->
        <aside id="sidebar">
            <div class="d-flex">
                
                <div class="sidebar-logo">
                    <a href="<?php echo e(route('dashboard.index')); ?>"><i class="bi bi-grid"></i><span
                            class="ps-2">Saycexapp</span></a>
                </div>
            </div>
            <ul class="sidebar-nav">
                <li class="sidebar-item active">
                    <a href="<?php echo e(route('dashboard.index')); ?>" class="sidebar-link">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read products')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('products.index')); ?>" class="sidebar-link">
                            <i class="bi bi-box-seam"></i>
                            <span>Productos</span>
                        </a>
                    </li>

                     <li class="sidebar-item">
                        <a href="<?php echo e(route('products.uploadForm')); ?>" class="sidebar-link">
                            <i class="bi bi-box-seam"></i>
                            <span>Carga de productos</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver codigosQR')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('products.report')); ?>" class="sidebar-link">
                            <i class="bi bi-box-seam"></i>
                            <span>QRcodes</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read customers')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('customers.index')); ?>" class="sidebar-link">
                            <i class="bi bi-people"></i>
                            <span>Clientes</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a href="<?php echo e(route('products.update-warehouse-qr')); ?>" class="sidebar-link">
                            <i class="bi bi-houses"></i> <span>AlmacénQR</span></a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read warehouses')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('warehouses.index')); ?>" class="sidebar-link">
                            <i class="bi bi-houses"></i>
                            <span>Almacenes</span>
                        </a>
                    </li>

                    
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read petitions')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('petitions.index')); ?>" class="sidebar-link">
                            <i class="bi bi-receipt"></i>
                            <span>Pedidos</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read orders')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('orders.index')); ?>" class="sidebar-link">
                            <i class="bi bi-inboxes"></i>
                            <span>Ordenes</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver abonos')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('payments.manage')); ?>" class="sidebar-link">
                            <i class="bi bi-inboxes"></i>
                            <span>Abonos</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read prices')): ?>
                    

                    

                    <li class="sidebar-item">
                        <a href="#precios-submenu" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="bi bi-receipt"></i>
                            <span>Precios</span>
                            <i class="bi bi-chevron-down ms-auto"></i>
                        </a>
                        <ul id="precios-submenu" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('prices.index')); ?>" class="sidebar-link">Precios Gen</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('prices.update-by-classification')); ?>" class="sidebar-link">Precios
                                    plus</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="<?php echo e(route('prices.customer-update')); ?>" class="sidebar-link">Precios Clientes</a>
                            </li>

                        </ul>
                    </li>

                    
                <?php endif; ?>

                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver clasificaciones')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('classifications.table')); ?>" class="sidebar-link">
                            <i class="bi bi-tags"></i>
                            <span>Clasificaciones</span>
                        </a>
                    </li>
                <?php endif; ?>

                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read users')): ?>
                    <li class="sidebar-item">
                        <a href="<?php echo e(route('users.index')); ?>" class="sidebar-link">
                            <i class="bi bi-person-lock"></i>
                            <span>Roles</span>
                        </a>
                    </li>
                <?php endif; ?>



                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver reportes')): ?>
                    <li class="sidebar-item">
                        <a href="#reports-submenu" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            <span>Reportes</span>
                            <i class="bi bi-chevron-down ms-auto"></i>
                        </a>
                        <ul id="reports-submenu" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">


                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.inventory-by-warehouse')); ?>" class="sidebar-link">Inv. por
                                    Almacén</a>
                            </li>



                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.historical-movements')); ?>" class="sidebar-link">Mov.
                                    Históricos</a>
                            </li>


                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.inventory-by-classification')); ?>" class="sidebar-link">Inv.
                                    Clasificación</a>
                            </li>


                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.inventory-by-classification-detail')); ?>"
                                    class="sidebar-link">Inv.
                                    Clasificación Detalle</a>
                            </li>

                        </ul>
                    </li>
                <?php endif; ?>
                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver movDetalles')): ?>
                    <li class="sidebar-item">
                        <a href="#reports-submenuadmin" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            <span>Reportes admin</span>
                            <i class="bi bi-chevron-down ms-auto"></i>
                        </a>
                        <ul id="reports-submenuadmin" class="sidebar-dropdown list-unstyled collapse"
                            data-bs-parent="#sidebar">

                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.detailed')); ?>" class="sidebar-link">Mov.
                                    Detalles</a>
                            </li>

                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.debt-report')); ?>" class="sidebar-link">Ctas.
                                    Cobrar</a>
                            </li>

                            <li class="sidebar-item">
                                <a href="<?php echo e(route('reports.payment-history')); ?>" class="sidebar-link">Hist.
                                    Abonos</a>
                            </li>

                        </ul>
                    </li>
                <?php endif; ?>



                <?php if(auth()->guard()->check()): ?>
                    <li class="sidebar-item">
                        <a href="#login-submenu" data-bs-toggle="collapse" class="sidebar-link collapsed">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            <span><?php echo e(Auth::user()->name); ?></span>
                            <i class="bi bi-chevron-down ms-auto"></i>
                        </a>
                        <ul id="login-submenu" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a class="sidebar-link" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>

                        </ul>
                    </li>

                <?php endif; ?>


                
            </ul>
            
        </aside>

        <!-- Page Content -->
        <div class="main">
            <nav class="navbar navbar-expand px-3 border-bottom">
                <button class="btn" id="sidebar-toggle" type="button">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Navbar elements here -->
            </nav>
            <main class="content px-4 py-3">
                <div class="container-fluid">
                    <?php echo e($slot); ?>

                </div>
            </main>
        </div>
    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/components/layouts/dashboard.blade.php ENDPATH**/ ?>