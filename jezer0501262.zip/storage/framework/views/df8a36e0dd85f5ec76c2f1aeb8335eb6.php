<div>

    <!--[if BLOCK]><![endif]--><?php if($abierto): ?>
        <!-- Fondo -->
        <div class="modal-backdrop fade show"></div>
        
        <!-- Modal -->
        <div class="modal fade show" style="display: block;" tabindex="-1">
            <div class="modal-dialog modal-fullscreen-sm-down">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Lector de QR</h5>
                        <button class="btn-close" wire:click="cerrar"></button>
                    </div>
                    <div class="modal-body">

                       <h2>Escaneando...</h2>
                       <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('order.qrscanner-order', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2570587986-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                       
                    </div>
                </div>
            </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



</div>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/order/modal-order.blade.php ENDPATH**/ ?>