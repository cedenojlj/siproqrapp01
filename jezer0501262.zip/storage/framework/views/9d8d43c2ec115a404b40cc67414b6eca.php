<div>
    <div class="container py-4">
        <div class="card">
            <div class="card-header">
                <h2>Gestión de Precios por Clasificación</h2>
            </div>
            <div class="card-body">
                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <div class="mb-3">
                    <input wire:model.live="search" type="text" class="form-control" placeholder="Buscar por código, descripción o tamaño...">
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Descripción</th>
                                <th>Tamaño</th>
                                <th>Tipo Unidad</th>
                                <th>Precio_por_Unidad</th>
                                <th>Precio_por_Peso</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $classifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr wire:key="<?php echo e($classification->id); ?>">
                                    <td><?php echo e($classification->code); ?></td>
                                    <td><?php echo e($classification->description); ?></td>
                                    <td><?php echo e($classification->size); ?></td>
                                    <td><?php echo e($classification->unit_type); ?></td>
                                    <td>
                                        <input type="number" class="form-control <?php $__errorArgs = ['preciosUnidad.'. $classification->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.lazy="preciosUnidad.<?php echo e($classification->id); ?>">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['preciosUnidad.'. $classification->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <input type="number" class="form-control <?php $__errorArgs = ['preciosPeso.'. $classification->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.lazy="preciosPeso.<?php echo e($classification->id); ?>">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['preciosPeso.'. $classification->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" wire:click="update(<?php echo e($classification->id); ?>)" wire:loading.attr="disabled">
                                            <span wire:loading.remove wire:target="update(<?php echo e($classification->id); ?>)">Guardar</span>
                                            <span wire:loading wire:target="update(<?php echo e($classification->id); ?>)">Guardando...</span>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                    <?php echo e($classifications->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\CEDENO\Desktop\PRACTICAS\siproqrapp01\resources\views/livewire/classification/table.blade.php ENDPATH**/ ?>