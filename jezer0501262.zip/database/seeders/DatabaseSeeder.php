<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Classification;
use App\Models\Customer;
use App\Models\Warehouse;
use App\Models\Product;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
       // User::factory(10)->create();

        /* User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]); */

       // Classification::factory(10)->create();

        //Customer::factory(1)->create();

        //Warehouse::factory(5)->create();
        
        //Product::factory(10)->create();

          // You can add more seeders here as needed
        $this->call([PermisosSeeder::class, 
                    WarehouseSeeder::class,
                    /*CustomerSeeder::class,
                     ClassificationSeeder::class */]);
    }
}
