<?php

namespace App\Livewire\Product;

use Livewire\Component;

class ModalProduct extends Component
{
    public function render()
    {
        return view('livewire.product.modal-product');
    }
}
